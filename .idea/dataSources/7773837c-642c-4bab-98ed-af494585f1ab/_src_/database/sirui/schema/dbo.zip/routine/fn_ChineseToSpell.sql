
CREATE function [dbo].[fn_ChineseToSpell](@strChinese varchar(500)='') 
returns varchar(500) 
as 
begin /*函数实现开始*/ 
    declare @strLen int,@return varchar(500),@i int 
    declare @n int,@c char(1),@chn nchar(1)  
    select @strLen=len(@strChinese),@return='',@i=0 
    while @i<@strLen 
    begin /*while循环开始*/
            select @i=@i+1,@n=63,@chn=substring(@strChinese,@i,1) 
            if @chn>'z'/*原理:“字符串排序以及ASCII码表”*/                
                select @n = @n +1,@c =case chn when @chn then char(@n) else @c end 
                  from(
						  select top 27 * 
							from (
													select  chn = '吖' 
										  union all select '八' 
										  union all select '嚓' 
										  union all select '咑' 
										  union all select '妸'  
										  union all select '发'  
										  union all select '旮'  
										  union all select '铪'  
										  union all select '丌' /*because have no 'i'*/ 
										  union all select '丌' 
										  union all select '咔' 
										  union all select '垃' 
										  union all select '嘸' 
										  union all select '拏' 
										  union all select '噢' 
										  union all select '妑' 
										  union all select '七' 
										  union all select '呥' 
										  union all select '仨' 
										  union all select '他' 
										  union all select '屲' /*no 'u'*/ 
										  union all select '屲' /*no 'v'*/ 
										  union all select '屲' 
										  union all select '夕' 
										  union all select '丫' 
										  union all select '帀' 
										  union all select @chn
								) as a  
						  order by chn COLLATE Chinese_PRC_CI_AS 
					 ) as b  
            else
                set @c=upper(@chn)
            set @return=@return+@c  
    end /*while循环结束*/  
    return(@return)  
end /*函数实现结束*/
