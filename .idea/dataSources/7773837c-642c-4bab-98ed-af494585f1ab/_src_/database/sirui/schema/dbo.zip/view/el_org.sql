/*==============================================================*/
/* View: el_org                                                 */
/*==============================================================*/
create view [dbo].[el_org] as
SELECT     DepID AS OID, Name, LevelCode AS TreeID, brandID, AssistPhone AS ComplantPhone, Phone, Name AS OrgName, Name AS Depname
FROM         dbo.Department
