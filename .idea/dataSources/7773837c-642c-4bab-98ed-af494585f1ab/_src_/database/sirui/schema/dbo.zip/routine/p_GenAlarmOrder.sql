-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	生成告警工单。将未生成警情工单的告警信息 存入到告警工单表中
-- =============================================
CREATE PROCEDURE [dbo].[p_GenAlarmOrder]
	
AS
	DECLARE 
		@V_MAXID int







