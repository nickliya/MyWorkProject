
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION  [dbo].[getParLevelCode] 
(
	-- Add the parameters for the function here
	@subLevelCode varchar(1024)
)
RETURNS varchar(1024)
AS
BEGIN
	declare @result varchar(1024);
	select @result=REVERSE (substring (REVERSE (@subLevelCode), CHARINDEX ('/', REVERSE (@subLevelCode)) + 1, len (@subLevelCode)));
	RETURN @result;
END

