
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[InitVehicleMaintenItems]
	-- Add the parameters for the stored procedure here
AS
	DECLARE @wiper int
	DECLARE @tire int
	DECLARE @battery int
	DECLARE @brakePads int
	
	declare vehicleCursor cursor --声明一个游标，查询满足条件的数据
	for select vehicleid from Vehicle order BY VehicleID 
	
BEGIN
	set @wiper = 10000
	set @tire = 30000
	set @battery = 40000
	set @brakePads = 50000
	
	OPEN vehicleCursor
	
	DECLARE @vehicleid int
		fetch next from vehicleCursor into @vehicleid
	
	while (@@fetch_status = 0)
		begin
			insert INTO  VehicleMaintenItem VALUES(@vehicleid, '刹车片', 50000, 0, 50000)
			insert INTO  VehicleMaintenItem VALUES(@vehicleid, '雨刮', 10000, 0, 10000)
			insert INTO  VehicleMaintenItem VALUES(@vehicleid, '轮胎', 30000, 0, 30000)
			insert INTO  VehicleMaintenItem VALUES(@vehicleid, '电瓶', 40000, 0, 40000)
			
			fetch next from vehicleCursor into @vehicleid
		end
		
	close vehicleCursor;
	deallocate vehicleCursor;--删除游标
		
END

