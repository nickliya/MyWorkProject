


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE  PROCEDURE [dbo].[GenMaintenOrder]
AS
	 
BEGIN

		
	--首保工单
    INSERT INTO [dbo].[MaintenOrder]([OrderType],[CreateTime],[ExpectDealTime],[VehicleID],[LevelCode],[Status],ExpirationTime,VisitExpirationTime,IsFirstCharge,ReservationType,MileAge)
		(select 3,getdate(),getdate(),VehicleID,v.LevelCode,1,
			DATEADD(day, op.ExpirationDay,getdate())
			,DATEADD(day, op.CloseDay + op.ExpirationDay, getdate()),
				(CASE WHEN GiftMaintenanceTimes = 0 AND maintenOrderCount = 0 THEN 1 
						WHEN GiftMaintenanceTimes = 0 AND maintenOrderCount >= 1	 then 2 
					  WHEN maintenOrderCount < GiftMaintenanceTimes then 0
					  WHEN maintenOrderCount = GiftMaintenanceTimes THEN 1
					  ELSE 2 end),'auto',MileAge
		   from [dbo].[Vehicle] v, [dbo].[Department] d, [dbo].[OrderParameter] op
		  where v.LevelCode = d.LevelCode
			AND d.ExtendOrderRule = op.LevelCode
			and mileage!=0
			and MileAge  > NextMaintenMileage - op.RemindMileage
		    AND maintenOrderCount = 0 
		    and VehicleID not in (select VehicleID from [dbo].[MaintenOrder] ))
			
	--大保工单
	INSERT INTO [dbo].[MaintenOrder]([OrderType],[CreateTime],[ExpectDealTime],[VehicleID],[LevelCode],[Status],ExpirationTime,VisitExpirationTime,IsFirstCharge,ReservationType,MileAge)
		(select 2,getdate(),getdate(),VehicleID, v.LevelCode,1,
			DATEADD(day, op.ExpirationDay, getdate())
			,DATEADD(day, op.CloseDay + op.ExpirationDay, getdate()),
				 (CASE WHEN GiftMaintenanceTimes = 0 AND maintenOrderCount = 0 THEN 1 
						WHEN GiftMaintenanceTimes = 0 AND maintenOrderCount >= 1	 then 2 
					  WHEN maintenOrderCount < GiftMaintenanceTimes then 0
					  WHEN maintenOrderCount = GiftMaintenanceTimes THEN 1
					  ELSE 2 end),'auto',MileAge
		   from [dbo].[Vehicle] v, [dbo].[Department] d, [dbo].[OrderParameter] op
		  where v.LevelCode = d.LevelCode
			AND d.ExtendOrderRule = op.LevelCode
			and mileage!=0
			and MileAge  > NextMaintenMileage - op.RemindMileage 
		    and NextMaintenMileage >= NextBigMaintenMileage
		    AND maintenOrderCount > 0 
			and VehicleID not in (select VehicleID from [dbo].[MaintenOrder]))

	--普通保养工单
    INSERT INTO [dbo].[MaintenOrder]([OrderType],[CreateTime],[ExpectDealTime],[VehicleID],[LevelCode],[Status],ExpirationTime,VisitExpirationTime,IsFirstCharge,ReservationType,MileAge)
		(select 1,getdate(),getdate(),VehicleID, v.LevelCode,1,
			DATEADD(day, op.ExpirationDay,getdate())
			,DATEADD(day, op.CloseDay + op.ExpirationDay, getdate()),
				(CASE WHEN GiftMaintenanceTimes = 0 AND maintenOrderCount = 0 THEN 1 
						WHEN GiftMaintenanceTimes = 0 AND maintenOrderCount >= 1	 then 2 
					  WHEN maintenOrderCount < GiftMaintenanceTimes then 0
					  WHEN maintenOrderCount = GiftMaintenanceTimes THEN 1
					  ELSE 2 end),'auto',MileAge
		   from [dbo].[Vehicle] v, [dbo].[Department] d, [dbo].[OrderParameter] op
		  where v.LevelCode = d.LevelCode
			AND d.ExtendOrderRule = op.LevelCode
			and mileage!=0
			and MileAge > NextMaintenMileage - op.RemindMileage  
			and NextMaintenMileage != NextBigMaintenMileage
		    AND maintenOrderCount>0 
		    and VehicleID not in (select VehicleID from [dbo].[MaintenOrder] ))


END

