/*==============================================================*/
/* View: Customer_Online                                        */
/*==============================================================*/
create view [dbo].[Customer_Online] as
SELECT     dbo.Customer.Name, dbo.Customer.Sex, dbo.Customer.Birthday, dbo.Customer.Phone, dbo.Customer.Email, dbo.Customer.CustomerManagerID, 
                      dbo.Department.DepID, dbo.Customer.CustomerID AS UserName, dbo.Customer.CustomerID AS UUID
FROM         dbo.Customer INNER JOIN
                      dbo.Department ON dbo.Customer.LevelCode = dbo.Department.LevelCode
