
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[p_OilPrice] 
AS
	declare @monthNext varchar(6)
	declare @countNext int
	declare @month varchar(6)
	declare @count int
BEGIN
	BEGIN TRANSACTION
	
	--每个月的第一天，插入下一个月的油价信息，具体值使用默认的0
	set @monthNext = convert(VARCHAR,DATEPART(yyyy,DATEADD(mm,1,getdate())))*100
               + convert(VARCHAR,DATEPART(mm,DATEADD(mm,1,getdate())))
	select @countNext=count(1) from [OilPrice] where [Month]=@monthNext
	
	set @month = convert(VARCHAR,DATEPART(yyyy,DATEADD(mm,0,getdate())))*100
               + convert(VARCHAR,DATEPART(mm,DATEADD(mm,0,getdate())))
	select @count=count(1) from [OilPrice] where [Month]=@month
	
    IF @countNext=0
		BEGIN 
			IF @count=0
			BEGIN 
				INSERT INTO [dbo].[OilPrice] ([Month],[OilType],[Price],[CreateDate]) VALUES (@monthNext,90,6.91,getdate());
				INSERT INTO [dbo].[OilPrice] ([Month],[OilType],[Price],[CreateDate]) VALUES (@monthNext,93,7.30,getdate());
				INSERT INTO [dbo].[OilPrice] ([Month],[OilType],[Price],[CreateDate]) VALUES (@monthNext,97,7.72,getdate());
				INSERT INTO [dbo].[OilPrice] ([Month],[OilType],[Price],[CreateDate]) VALUES (@monthNext,0,7.11,getdate());
			END 
			IF @count>0
			BEGIN 
				INSERT INTO [dbo].[OilPrice] ([Month],[OilType],[Price],[CreateDate]) VALUES (@monthNext,90,(select [Price] from [dbo].[OilPrice] where [Month]=@month AND [OilType]=90),getdate());
				INSERT INTO [dbo].[OilPrice] ([Month],[OilType],[Price],[CreateDate]) VALUES (@monthNext,93,(select [Price] from [dbo].[OilPrice] where [Month]=@month AND [OilType]=93),getdate());
				INSERT INTO [dbo].[OilPrice] ([Month],[OilType],[Price],[CreateDate]) VALUES (@monthNext,97,(select [Price] from [dbo].[OilPrice] where [Month]=@month AND [OilType]=97),getdate());
				INSERT INTO [dbo].[OilPrice] ([Month],[OilType],[Price],[CreateDate]) VALUES (@monthNext,0,(select [Price] from [dbo].[OilPrice] where [Month]=@month AND [OilType]=0),getdate());
			END 
		END 
	COMMIT TRANSACTION
END

