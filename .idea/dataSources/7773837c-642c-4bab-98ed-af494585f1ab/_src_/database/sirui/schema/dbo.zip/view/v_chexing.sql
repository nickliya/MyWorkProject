

CREATE view v_chexing as
SELECT
	v.VehicleModelID AS vmID,
	v.Name AS vmName,
	b.BrandID AS bID,
	b.Name AS bName,
	s.SeriesID AS sID,
	s.Name AS sName
FROM	VehicleModel v,
		Series s,
		Series_VehicleModel sv,
		Brand b,
		Brand_Series bs
WHERE b.BrandID = bs.BrandID AND bs.SeriesID = s.SeriesID AND s.SeriesID = sv.SeriesID AND sv.VehicleModelID = v.VehicleModelID
