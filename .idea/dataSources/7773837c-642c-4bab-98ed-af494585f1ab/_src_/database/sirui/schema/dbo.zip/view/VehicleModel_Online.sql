/*==============================================================*/
/* View: VehicleModel_Online                                    */
/*==============================================================*/
create view [dbo].[VehicleModel_Online] as
SELECT     t.VehicleModelID, t.Name, m.BrandID, 4 AS seats, 1 AS price, t.Name AS vehiclename, t.Name AS VehicleModelName
FROM         dbo.VehicleModel AS t INNER JOIN
                      dbo.Series_VehicleModel AS s ON t.VehicleModelID = s.VehicleModelID INNER JOIN
                      dbo.Series AS c ON s.SeriesID = c.SeriesID INNER JOIN
                      dbo.Brand_Series AS m ON c.SeriesID = m.SeriesID
