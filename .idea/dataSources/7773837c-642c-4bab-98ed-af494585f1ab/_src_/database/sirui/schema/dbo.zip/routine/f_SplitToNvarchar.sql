

CREATE FUNCTION [dbo].[f_SplitToNvarchar]
(
@SourceSql   NVARCHAR(MAX),--源分隔字符串
@StrSeprate  VARCHAR(10)--分隔符
)
RETURNS @temp TABLE(col NVARCHAR(MAX))
AS
BEGIN
DECLARE @i INT
SET @SourceSql = RTRIM(LTRIM(@SourceSql))
SET @i = CHARINDEX(@StrSeprate, @SourceSql)
WHILE @i >= 1
BEGIN
    INSERT @temp
    VALUES
      (
        LEFT(@SourceSql, @i -1)
      )
    SET @SourceSql = SUBSTRING(@SourceSql, @i + 1, LEN(@SourceSql) -@i)
    SET @i = CHARINDEX(@StrSeprate, @SourceSql)
END
IF @SourceSql <> '\'
    INSERT @temp
    VALUES
      (
        @SourceSql
      )
RETURN
END
