




-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	每月16号0点执行上月的工单处理统计
-- =============================================
CREATE PROCEDURE [dbo].[p_MaintenOrderReport]
AS
	declare @month varchar(12)
BEGIN
	BEGIN TRANSACTION  
	
    --获取上月月份
    set @month = convert(VARCHAR,DATEPART(yy,DATEADD(ms,-3,DATEADD(mm, DATEDIFF(m,0,getdate()), 0)))) 
               + convert(VARCHAR,DATEPART(mm,DATEADD(ms,-3,DATEADD(mm, DATEDIFF(m,0,getdate()), 0)))) 
    
	--获取工单总数
	--获取工单处理的数量
	--获取工单处理的数量（成功）
	--获取工单第一次收费的数量
	--获取工单第一次收费的数量（成功）
	--获取工单中大保的数量
	--获取工单中大保的数量（成功）
	--获取工单中事故的数量
	--获取工单中事故的数量（成功）
	
	INSERT INTO [dbo].[MaintenOrderReport]
           ([totalNumber],[processNumber],[processNumberSuccess],[firstChargeNumber],[firstChargeNumberSuccess]
           ,[bigNumber],[bigNumberSuccess],[accidentNumber],[accidentNumberSuccess],[IsOutOfServiceChargeNum],[ioosChargeNumSuccess]
           ,[levelCode],[month])		  
		  select	
				(ISNULL(H.totalNumber,0) + ISNULL(J.totalNumber,0)) totalNumber,
				ISNULL(H.processNumber,0) processNumber,
				ISNULL(H.processNumberSuccess + J.accidentNumberSuccess,0) processNumberSuccess,
				ISNULL(H.firstChargeNumber,0) firstChargeNumber,
				ISNULL(H.firstChargeNumberSuccess,0) firstChargeNumberSuccess,
				ISNULL(H.bigNumber,0) bigNumber,
				ISNULL(H.bigNumberSuccess,0) bigNumberSuccess,
				ISNULL(J.accidentNumber,0) accidentNumber,
				ISNULL(J.accidentNumberSuccess,0) accidentNumberSuccess,
				ISNULL(h.IsOutOfServiceChargeNum,0) IsOutOfServiceChargeNum,
				ISNULL(h.ioosChargeNumSuccess,0) ioosChargeNumSuccess,
				isnull(H.levelCode,J.levelCode) levelCode,
				@month
		  from  (
				--保养工单   
				select sum(1)																as totalNumber,
					   sum((case when status not in(1,2)		  		then 1 else 0 END)) as processNumber,
					   sum((case when status = 5						then 1 else 0 END)) as processNumberSuccess,
					   sum((case when isFirstCharge = 1					then 1 else 0 END)) as firstChargeNumber,
					   sum((case when (isFirstCharge = 1 and status=5)  then 1 else 0 END)) as firstChargeNumberSuccess,
					   sum((case when orderType = 2						then 1 else 0 END)) as bigNumber,
					   sum((case when (orderType = 2 and Status=5)		then 1 else 0 END)) as bigNumberSuccess,
					   SUM((CASE WHEN (A.IsOutOfServiceCharge = 1)		THEN 1 ELSE 0 END )) as IsOutOfServiceChargeNum, 
					   SUM((CASE WHEN (A.IsOutOfServiceCharge = 1 and A.Status = 5)		THEN 1 ELSE 0 END )) as ioosChargeNumSuccess,
					   A.levelCode
				  from (
							SELECT * from MaintenOrder
							 WHERE  DATEPART(yy,CreateTime) = DATEPART(yy,DATEADD(ms,-3,DATEADD(mm, DATEDIFF(m,0,getdate()), 0)))
							   AND  DATEPART(mm,CreateTime) = DATEPART(mm,DATEADD(ms,-3,DATEADD(mm, DATEDIFF(m,0,getdate()), 0)))	
							union ALL 
							select * from MaintenOrderHistory
							 WHERE  DATEPART(yy,CreateTime) = DATEPART(yy,DATEADD(ms,-3,DATEADD(mm, DATEDIFF(m,0,getdate()), 0)))
							   AND  DATEPART(mm,CreateTime) = DATEPART(mm,DATEADD(ms,-3,DATEADD(mm, DATEDIFF(m,0,getdate()), 0)))
						) A
				  group by A.levelCode	   
				  )H
		  full join (	  
				--警情工单
			    select sum(1) as totalNumber,
					   sum(1) as accidentNumber,
					   sum((case when status = 4			then 1 else 0 END)) as accidentNumberSuccess,
					   A.levelCode
				  from (	
							select * from AlarmOrder
							 WHERE  DATEPART(yy,UTCTime) = DATEPART(yy,DATEADD(ms,-3,DATEADD(mm, DATEDIFF(m,0,getdate()), 0)))
							   AND  DATEPART(mm,UTCTime) = DATEPART(mm,DATEADD(ms,-3,DATEADD(mm, DATEDIFF(m,0,getdate()), 0)))	
							union all
							select * FROM AlarmOrderHistory
							 WHERE  DATEPART(yy,UTCTime) = DATEPART(yy,DATEADD(ms,-3,DATEADD(mm, DATEDIFF(m,0,getdate()), 0)))
							   AND  DATEPART(mm,UTCTime) = DATEPART(mm,DATEADD(ms,-3,DATEADD(mm, DATEDIFF(m,0,getdate()), 0)))	
						) A
				  group by A.levelCode
				  )J 
		  on H.levelCode = J.levelCode
		  
	COMMIT TRANSACTION
END





