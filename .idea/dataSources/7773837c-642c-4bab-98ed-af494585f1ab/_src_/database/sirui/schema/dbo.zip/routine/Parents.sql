
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	判断是否是@subString 的上级部门
-- =============================================
CREATE FUNCTION [dbo].[Parents]
(
	-- Add the parameters for the function here
	@subString varchar(1024),
	@parentString varchar(1024)
)
RETURNS int
AS
BEGIN
	declare @result int;
	if(@subString = @parentString)
		return 0;
	else
		SELECT @result = CHARINDEX(@parentString+'/',@subString,0);
		if(@result >=1)
			return 1
	return 0 ;
END


