/*==============================================================*/
/* View: el_user                                                */
/*==============================================================*/
create view [dbo].[el_user] as
SELECT     dbo.[User].UserID AS UID, CONVERT(VARCHAR(19), dbo.[User].UserID) AS UserName, dbo.[User].Name AS RealName, dbo.[User].Name AS UUID, 
                      dbo.Department.DepID AS oid, dbo.[User].Password AS psw, 1 AS active
FROM         dbo.[User] INNER JOIN
                      dbo.Department ON dbo.[User].LevelCode = dbo.Department.LevelCode
