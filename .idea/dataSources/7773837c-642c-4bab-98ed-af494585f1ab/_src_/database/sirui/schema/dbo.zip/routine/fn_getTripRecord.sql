CREATE FUNCTION [dbo].[fn_getTripRecord] (
	@in_vehicleID int,
	@in_startTime datetime,
	@in_endTime datetime
)

RETURNS @retTripRecord TABLE 
( 
    [TripID] varchar(1024)  NOT NULL,
	[VehicleID] [int] NOT NULL,
	[StartTime] [datetime] NOT NULL,
	[EndTime] [datetime] NOT NULL,
	[Mileage] [int] NOT NULL,
	[FuelCons] [float] NOT NULL,
	[AvgFuelCons] [float] NOT NULL,
	[Fee] [float] NOT NULL,
	[StartLat] [float] NULL,
	[StartLng] [float] NULL,
	[EndLat] [float] NULL,
	[EndLng] [float] NULL
)
as
	
begin	
	declare @tripID  varchar(1024),	@c_tripID varchar(1024);
	declare @mileage float,			@c_mileage float;
	declare @fuelCons float,		@c_fuelCons float;
	declare @avgFuelCons float,		@c_avgFuelCons float;
	declare @fee float,				@c_fee float;
	declare @startLat float,		@first_startLat float;
	declare @startLng float,		@first_startLng float;
	declare @endLat float,			@pre_endLat float;
	declare @endLng float,			@pre_endLng float;
	declare @startTime datetime,    @pre_startTime datetime  ,  @first_startTime datetime;  
	declare @endTime datetime,		@pre_endTime  datetime;
	declare @intervalTime int;
	DECLARE @index   int;

	declare v_trip cursor for 
			 select tripID,mileage,fuelCons,
					avgFuelCons,fee,startLat,startLng,endLat,endLng,
				    DATEADD(hh,DATEDIFF(hh,GETDATE(),GETUTCDATE()),StartTime) startTime,
					DATEADD(hh,DATEDIFF(hh,GETDATE(),GETUTCDATE()),endTime) endTime
			  from  TripRecord
			 where  VehicleID =  @in_vehicleID
			   and  DATEADD(hh,DATEDIFF(hh,GETDATE(),GETUTCDATE()),StartTime)   between @in_startTime and @in_endTime
			   AND	ISEFFECTIVE = 1
			   AND  (mileage >= 100 or (fuelCons > 0 and mileage>10))
			 order  by startTime
			 
			 
	SET @index = 1;
	
	OPEN v_trip
		Fetch next From v_trip into @tripID,@mileage,@fuelCons,@avgFuelCons,@fee,@startLat,@startLng,@endLat,@endLng,@startTime,@endTime
		
		while @@fetch_status = 0 ---瀛樺湪鏈瓎鍊煎悜涓嬪惊鐠?
								---(0锛氶爢鍒╁煼琛?-1锛氬け鏁楋紝鎴栬硣鏂欏垪瓒呭嚭绲愭灉闆?-2锛氭摲鍙栫殑璩囨枡鍒楀凡閬烘紡)
		BEGIN
				IF @index=1 
					BEGIN
						SET @c_tripID  = @tripID;
						SET @c_mileage = @mileage;
						SET @c_fuelCons = @fuelCons;
						SET @c_avgFuelCons = @avgFuelCons;
						SET @c_fee =		 @fee;
						SET @pre_startTime = @startTime;
						SET @pre_endTime   = @endTime;
						SET @first_startTime = @startTime;
						SET @first_startLat = @startLat
						SET @first_startLng = @startLng
						SET @pre_endLat 		= @endLat
						SET @pre_endLng			= @endLng
					END
				ELSE
					BEGIN
							
							SELECT @intervalTime=value from SystemParameter where namekey='gateway.trip.intervalTime'
							IF @intervalTime=NULL
								BEGIN
								   SET @intervalTime = 5
								END
								
							IF DATEDIFF(Mi,@pre_endTime ,@startTime) <= @intervalTime
								 BEGIN
								 		SET @c_tripID = @c_tripID + ',' + @tripID;
								 		SET @c_mileage = @c_mileage + @mileage;
								 		SET @c_fuelCons = @c_fuelCons + @fuelCons;
								 		
								 		SET @c_fee =	@c_fee + 	 @fee;
								 		SET @pre_endTime   = @endTime;
										SET @pre_startTime = @startTime;
										SET @pre_endLat 		= @endLat
										SET @pre_endLng			= @endLng
										
								 		IF @first_startTime = NULL
								 			 BEGIN
								 					SET @first_startTime = @startTime;
								 			 END
								 				
								 		IF @c_mileage = 0
								 			 BEGIN
								 			 		SET @c_avgFuelCons = 0
								 			 END
										ELSE
											 BEGIN
												  SET @c_avgFuelCons = @c_fuelCons/(@c_mileage*0.00001);
											 END
								 END
							ELSE
							   BEGIN
							   		INSERT @retTripRecord
							   		 VALUES(@c_tripID,@in_vehicleID,@first_startTime,@pre_endTime,@c_mileage,@c_fuelCons,@c_avgFuelCons,@c_fee,@first_startLat,@first_startLng,@pre_endLat,@pre_endLng);
							   		 
							   		
							   		SET @pre_startTime = @startTime;
							   		SET @pre_endTime = @endTime;
							   		SET @c_tripID = @tripID;
							   		SET @c_mileage = @mileage;
							   		SET @c_fuelCons = @fuelCons;
							   		SET @c_avgFuelCons = @avgFuelCons;
							   		SET @c_fee = @fee;
							   		SET @first_startTime = @startTime;
							   		SET @first_startLat = @startLat
									SET @first_startLng = @startLng
									SET @pre_endLat 		= @endLat
									SET @pre_endLng			= @endLng
							   END
					END
		
				SET @index = @index + 1
				Fetch next From v_trip into @tripID,@mileage,@fuelCons,@avgFuelCons,@fee,@startLat,@startLng,@endLat,@endLng,@startTime,@endTime
				
				IF @@fetch_status != 0
					 BEGIN
					 		INSERT @retTripRecord
							   		 VALUES(@c_tripID,@in_vehicleID,@first_startTime,@pre_endTime,@c_mileage,@c_fuelCons,@c_avgFuelCons,@c_fee,@first_startLat,@first_startLng,@pre_endLat,@pre_endLng);
							   		 
					 END
		END
		
	CLOSE v_trip 
	deallocate v_trip  --绉婚櫎璩囨枡鎸囨鍙冭€?	 
		
			 

	RETURN 
end
