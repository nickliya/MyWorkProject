

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================

CREATE FUNCTION [dbo].[LRLike]
(
	-- Add the parameters for the function here
	@queryString varchar(1024),
	@columnString varchar(1024)
)
RETURNS int
AS
BEGIN
	declare @result int;
	SELECT @result = CHARINDEX(@queryString,@columnString,0);
	if(@result >= 1)
		return 1;
		return 0;
END
