-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[p_SendBirthdayMessage]
	
AS
	declare v_customer cursor for 
			select c.customerID,c.name,c.phone,c.levelCode
			  FROM customer c
			 WHERE convert	(VARCHAR,DATEPART(mm,c.Birthday)) + convert(VARCHAR,DATEPART(dd,c.Birthday)) =
				   convert	(VARCHAR,DATEPART(mm,getdate())) + convert(VARCHAR,DATEPART(dd,getdate()))
			   and c.phone is not null
			 order by c.levelCode; 
	DECLARE @customerID int		   
	DECLARE @username varchar(256)
	DECLARE @phone varchar(256)
	DECLARE @levelCode varchar(256)			  ---本次客户的levelcode
	DECLARE @levelCode_pre varchar(256)        ---上次客户的levelcode
	DECLARE @content varchar(256)			  ---本次客户的content
	DECLARE @content_pre varchar(256)		  ---上次客户的content
	DECLARE @businessPlanIDs varchar(256)
	DECLARE @sql varchar(8000)
	
	DECLARE @count int
	DECLARE @batchID int				  ---本次客户的batchID
	DECLARE @batchID_pre int			  ---上次客户的batchID
	DECLARE @v_name varchar(256)
	DECLARE @businessPlanName varchar(256)		  ---本次客户的businessPlanName
	DECLARE @businessPlanName_pre varchar(256)	  ---上次客户的businessPlanName_pre
  
	DECLARE @index int					   ---循环次数
	
BEGIN
	--获取所有当天生日的客户
	--循环所有客户(找到客户对应部门 的生日模版)
		
Begin TRANSACTION                                       

	set @index = 1;
	open v_customer
		Fetch next From v_customer into @customerID,@username,@phone,@levelCode
		
		while @@fetch_status = 0 ---存在本筆值向下循環
								---(0：順利執行;-1：失敗，或資料列超出結果集;-2：擷取的資料列已遺漏)
		begin
				--初始化@levelCode_pre
				if @index=1
					begin
						set @levelCode_pre = @levelCode
					end
					
				--如果本次的levelCode 和上次的levelCode不同，则重新获取levelCode_pre content_pre businessPlanName_pre
				if @levelCode != @levelCode_pre or @index=1
					begin
							--读取生日模版
							select @count = count(1)
							  FROM messageTmpl m
							 where m.Type=1
							   and m.LevelCode = @levelCode
							
							
							
							--判断是否有生日模版，如果无，则输入默认信息Happy BirthDay!
							--为@content @content_pre @businessPlanName @businessPlanName_pre 赋值
							IF @count=0 
								begin
									set @content ='HappyBirthDay!'
									set @businessPlanName = ''
								end
							else
								BEGIN
									set @content = ''
									set @businessPlanName = ''
									--读取生日模版
									select @content = m.Content,@businessPlanIDs = m.BusinessPlanIDs 
									  FROM messageTmpl m
									 where m.Type=1
									   and m.LevelCode = @levelCode;  
									   
									
									
									--判断@businessPlanIDs是否为空
									IF @businessPlanIDs is not null and @businessPlanIDs !=''
										BEGIN
										set @sql='declare v_businessPlan cursor for  select b.name
											   from businessPlan b
											  where b.BusinessPlanID IN(' + @businessPlanIDs + ')'
											exec (@sql) 
											  
											  
											  open v_businessPlan
												   Fetch next From v_businessPlan into @v_name
												   while @@fetch_status = 0
												   BEGIN
												   set @businessPlanName = @businessPlanName + ' ' + @v_name ;
												    Fetch next From v_businessPlan into @v_name
												   end
											  close v_businessPlan
											  
											  set @businessPlanName		= ' 商业计划：' + @businessPlanName
										END
								 END	
							
							
							--往messageBatch  表存储信息
							insert into [dbo].[MessageBatch]([LevelCode],[Name],[Memo],[CreateTime])
							   values(@levelCode,'HAPPY BIRTHDAY!','',getdate());
						    set @batchID=@@IDENTITY
						    
						    set @levelCode_pre = @levelCode
							set @content_pre = @content
							set @businessPlanName_pre = @businessPlanName
						    set @batchID_pre = @batchID
					end
				ELSE
					BEGIN
						SET @businessPlanName = @businessPlanName_pre
						set @levelCode		  = @levelCode_pre
						set @content		  = @content_pre
						set @batchID          = @batchID_pre
					end
				
				
				
				   
				
			
				--往message  表存储信息		   
				insert into [dbo].[Message]([BatchID],[CustomerName],[CustomerID],[CustomerPhone]
							,[Content],[SendTime],[Status],[FailCount],[LevelCode]
        					,[SendTimeStart],[SendTimeEnd])
					 values(@batchID,@username,@customerID,@phone
        					,@content + @businessPlanName,NULL,1,0,@levelCode,
        					cast((convert(varchar(10),getdate(),120)+' 09:00:00') as datetime),
        					cast((convert(varchar(10),getdate(),120)+' 18:00:00') as datetime)
        					)
		        		    
				SET @index = @index + 1
				
				Fetch next From v_customer into @customerID,@username,@phone,@levelCode
		end
		
	close v_customer 
	deallocate v_customer  --移除資料指標參考	
Commit TRANSACTION                                       
END
