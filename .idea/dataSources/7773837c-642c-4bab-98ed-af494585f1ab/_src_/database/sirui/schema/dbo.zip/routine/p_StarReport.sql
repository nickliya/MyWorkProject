
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[p_StarReport]
AS
	declare @month varchar(12)
BEGIN
	BEGIN TRANSACTION  
	
    --每月初对每个部门车辆的五个星级 进行数量统计
    set @month = convert(VARCHAR,DATEPART(yy,DATEADD(ms,-3,DATEADD(mm, DATEDIFF(m,0,getdate()), 0)))) 
               + convert(VARCHAR,DATEPART(mm,DATEADD(ms,-3,DATEADD(mm, DATEDIFF(m,0,getdate()), 0)))) 
    
    INSERT into StarReport ( newCarStar,twoOneStar,threeStar,fourStar,fiveStar,sumStar,levelCode,[month])
	SELECT  
			sum((case    WHEN Star=5 and maintenOrderCount <= GiftMaintenanceTimes THEN 1 else 0 end)) as newCarStar,
			sum((case	 when star=2 OR Star=1 then 1 else 0 END)) as twoOneStar,
			sum((case	 when star=3 then 1 else 0 END)) as threeStar,
			sum((case	 when star=4 then 1 else 0 END)) as fourStar,
			sum((case	 when Star=5 and maintenOrderCount >  GiftMaintenanceTimes then 1 else 0 END)) as fiveStar,
			sum(1) as sumStar,
			levelCode,
			@month
	 from vehicle
	group by LevelCode
	
	COMMIT TRANSACTION
END

