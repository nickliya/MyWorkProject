/*==============================================================*/
/* View: brand_online                                           */
/*==============================================================*/
create view [dbo].[brand_online] as
SELECT     BrandID, Name, Name AS BrandName
FROM         dbo.Brand
