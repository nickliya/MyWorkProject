


Create PROCEDURE [dbo].[Pro_updateVehicleTerID]

as
begin

declare updateVehicleTerIDCursor cursor --声明一个游标，查询满足条件的数据
for SELECT
	TerminalID,
	BarCode

FROM Terminal

open updateVehicleTerIDCursor --打开




declare @terminalID int, @barcode varchar (64) --声明一个变量，用于读取游标中的值
fetch next from updateVehicleTerIDCursor into @terminalID, @barcode

while @@fetch_status = 0 --循环读取
begin
--print @noToUpdate
UPDATE Vehicle
SET TerminalID = @terminalID
WHERE Barcode = @barcode
fetch next from updateVehicleTerIDCursor into @terminalID, @barcode
end

close updateVehicleTerIDCursor --关闭

deallocate updateVehicleTerIDCursor --删除

end



